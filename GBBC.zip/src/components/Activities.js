import styled from "@emotion/styled";
import React from "react";
import { Box, Typography, Container } from "@mui/material";
import styles from "../styles/Home.module.css";
import { Card, CardContent, IconButton } from "@mui/material";
import ArrowRightAltIcon from "@mui/icons-material/ArrowRightAlt";

const StyledContainer = styled(Box)({
  padding: "120px 70px",
  backgroundColor: "#fff",
  display : 'flex',
  flexDirection : 'column',
  justifyContent : 'center',

});

function Activities() {
  const images = [
    "/static/one.jpg",
    "/static/two.jpg",
    "/static/three.jpg",
    // Add more image URLs as needed
  ];

  const cardStyle = {
    position: "relative",
    minHeight: "482px", // Set a minimum height for the card
    width: "412px",
    margin : 'auto',
    backgroundSize: "cover",
    backgroundPosition: "center",
    transition: "filter 0.3s ease-in-out",
    overflow: "hidden",
  };

  const cardImageStyle = {
    position: "absolute",
    width: "100%",
    height: "100%",
    objectFit: "cover",
    transition: "filter 0.3s ease-in-out",
  };

  const contentStyle = {
    position: "absolute",
    bottom: "0",
    left: "0",
    padding: "50px 24px",
    color: "#fff",
    maxWidth: "299px",
  };

  const cardContainerStyle = {
    display: "flex",
    marginTop: "70px",
    alignItems: "center",
    justifyContent: "space-between",
    flexWrap: "wrap",
    gap: "20px", // Adjust the gap between cards
  };

  const iconStyle = {
    position: "absolute",
    padding: "1px 20px",
    bottom: "50px",
    right: "24px",
    borderRadius: "30px",
    border: "2px solid #00B0E9",
    gap: "10px",
  };

  const handleMouseEnter = (e) => {
    e.target.style.filter = "none";
  };

  const handleMouseLeave = (e) => {
    e.target.style.filter = "grayscale(5%) blur(4px)";
  };

  return (
    <StyledContainer>
      <Box
        sx={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent : 'center' }}
      >
        <Typography className={styles.activityhead}>Activities</Typography>
        <Typography className={styles.activitypara}>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua
        </Typography>
      </Box>
      <Box sx={cardContainerStyle}>
        {images.map((image, index) => (
          <Card
            key={index}
            sx={cardStyle}
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
          >
            <img src={image} alt="activity" style={cardImageStyle} />
            <CardContent sx={{ ...contentStyle, zIndex: "1" }}>
              <Typography className={styles.activityPhoto}>
                Policy and Regulatory Engagement
              </Typography>
            </CardContent>
            <Box sx={iconStyle}>
              <ArrowRightAltIcon sx={{ color: "#fff", fontSize: "40px" }} />
            </Box>
          </Card>
        ))}
      </Box>
    </StyledContainer>
  );
}

export default Activities;


