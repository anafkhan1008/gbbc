import React from 'react'
import styles from '../styles/Home.module.css'
import {Box, Typography , Button } from '@mui/material'
import { useTheme, useMediaQuery } from '@mui/material';


function Join() {
const theme = useTheme();
const isMediumScreen = useMediaQuery(theme.breakpoints.up('md'));
  return (
    <Box className={styles.joinbox} sx={{ display: 'block', zIndex : "100" , margin: isMediumScreen ? '0 130px' : '0', position: 'relative', top: isMediumScreen ? '-170px' : '0' , 
    bottom: isMediumScreen ? '200px' : '0' }}  >
        <Typography className={styles.joinhead}> Join the GBBC </Typography>
        <Typography className={styles.joinheadtwo} > Blurb about membership </Typography>
        <Typography className={styles.joinheadthree}> Lorem ipsum dolor sit amet consectetur, adipisicing elit. Accusantium, animi vero! Et consequuntur </Typography>

        <Button variant='container' className={styles.joinbutton}>
            <Typography className={styles.joinbuttoninside}>   Become a member </Typography>
       
        </Button>
    </Box>
  )
}

export default Join