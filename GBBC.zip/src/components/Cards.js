import React, { useState , useRef } from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import { Box, IconButton } from '@mui/material';
import styled from '@emotion/styled';
import styles from '../styles/Home.module.css'
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import OpenInNewIcon from '@mui/icons-material/OpenInNew';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
const SampleNextArrow = ({ onClick }) => (
    <IconButton style={{ position: 'absolute', top: '108%', right: '40%', transform: 'translateY(-50%)' }} onClick={onClick}>
      <ArrowForwardIosIcon sx={{fontSize : "24px" , color : "#00306F"}}/>
    </IconButton>
  );
  
  const SamplePrevArrow = ({ onClick }) => (
    <IconButton style={{ position: 'absolute', top: '108%', left: '40%', transform: 'translateY(-50%)' }} onClick={onClick}>
      <ArrowBackIosIcon sx={{fontSize : "24px" , color : "#00306F"}} />
    </IconButton>
  );

const cardsData = [
    {
      id: 1,
      title: 'New Post',
      image: '/static/one.jpg',
      description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. ',
    },
    {
      id: 2,
      title: 'New Post',
      image: '/static/two.jpg',
      description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. ',
    },
    {
      id: 3,
      title: 'New Post',
      image: '/static/three.jpg',
      description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. ',
    },
    {
      id: 4,
      title: 'New Post',
      image: '/static/one.jpg',
      description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. ',
    },
    {
      id: 5,
      title: 'New Post',
      image: '/static/two.jpg',
      description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. ',
    },
    {
      id: 6,
      title: 'New Post',
      image: '/static/three.jpg',
      description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. ',
    },
  ];
  

const StyledCards = styled(Box)({
  backgroundColor: '#DDEDFC',
  position: 'relative',
  paddingBottom : '200px'
  
});





export default function Cards() {

     const handleDotClick = (index) => {
        setActiveDot(index);
      };
  
    const settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 3,
        slidesToScroll: 1,
        nextArrow: <SampleNextArrow />,
        prevArrow: <SamplePrevArrow />,
      customPaging: (i) => (
        <div
          style={{
            marginTop : "25px",
            display : 'flex',
            marginRight: '30px',
            width: '30px',
            height: '11px',
            backgroundColor: activeDot === i ? '#00306F' : ' ',
            borderRadius : "25px",
            cursor: 'pointer',
          }}
          onClick={() => setActiveDot(i)}
        ></div>
      )
        
      };
    const [activeDot, setActiveDot] = useState(0);
    
   

  return (
    <StyledCards style={{ marginTop: '50px' }}>

    <Typography className={styles.newshead}>News</Typography>

    <Box sx={{padding : "80px"}} >
  <Slider
    {...settings}
    afterChange={(index) => setActiveDot(index)}
    initialSlide={activeDot}
  >
    {cardsData.map((card) => (
      <div key={card.id}>
        <Card sx={{ maxWidth: 420 , position : 'relative' , zIndex : "100" }}>
          <CardMedia
            sx={{ height: 216 , padding : '12px 24px' , display : 'flex' }}
            image={card.image}
            title={card.title}
          />
          <CardContent sx={{padding : '24px'}} >
            <Typography gutterBottom variant="h5" component="div" sx={{color : '#060B43' , fontFamily : 'Titillium Web', fontSize : '24px' , fontWeight : '700'}} >
              {card.title}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              {card.description}
            </Typography>
          </CardContent>
          <CardActions>
            <Button className={styles.seemore}>See more</Button>
            <OpenInNewIcon sx={{width : '20px' , height : '20px' , color : '#005A9B'}} />
          </CardActions>
        </Card>
      </div>
    ))}
  </Slider>
 </Box>
 <Box className = {styles.outerbox} >

     <Box className = {styles.newsbutton} >
    <Typography className={styles.newsinside}  >View More News</Typography>
    <ArrowForwardIcon sx={{color : '#005A9B'}} />
 </Box>
 </Box>



</StyledCards>  
  );
}




  
 
 