import React from 'react'
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import Image from 'next/image';
import Typography from '@mui/material/Typography'
import styles from '../styles/Home.module.css'
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';

function Footer() {
  return (
    <Box sx={{padding : "112px" , backgroundColor : '#060B43' , display : "block" , position : 'relative' , top : "-443px"}} >
   <Box sx={{ flexGrow: 1 , paddingTop : "340px" }}>
      <Grid container spacing={2} flexGrow={1} >
        <Grid item xs={3}>
         <Image 
          src="/static/logo.png"
          width={186}
          height={80}
          />
          <Box sx={{display : 'flex' ,justifyContent : 'center' , alignItems : 'center' , padding : "20px"}} >
             <Typography variant="h6" color="initial" className={styles.footerpara}> Back to top <ArrowUpwardIcon/> </Typography>
          </Box>
         
        </Grid>
        <Grid item xs={3} sx={{display : 'flex' , flexDirection : 'column'}} >
          <Typography className={styles.footerhead}> Programs </Typography>
          <Typography variant="caption" color="initial" className={styles.footerpara} >lorem ipsum</Typography>
          <Typography variant="caption" color="initial" className={styles.footerpara}>lorem ipsum</Typography>
          <Typography variant="caption" color="initial" className={styles.footerpara}>lorem ipsum</Typography>
          <Typography variant="caption" color="initial" className={styles.footerpara}>lorem ipsum</Typography>
          <Typography variant="caption" color="initial" className={styles.footerpara}>lorem ipsum</Typography>
        </Grid>
        <Grid item xs={3} sx={{display : 'flex' , flexDirection : 'column'}} >
        <Typography className={styles.footerhead}> Engage </Typography>
          <Typography variant="caption" color="initial" className={styles.footerpara}>lorem ipsum</Typography>
          <Typography variant="caption" color="initial" className={styles.footerpara}>lorem ipsum</Typography>
          <Typography variant="caption" color="initial" className={styles.footerpara}>lorem ipsum</Typography>
          <Typography variant="caption" color="initial" className={styles.footerpara}>lorem ipsum</Typography>
          <Typography variant="caption" color="initial" className={styles.footerpara}>lorem ipsum</Typography>
        </Grid>
        <Grid item xs={3} sx={{display : 'flex' , flexDirection : 'column'}}>
        <Typography className={styles.footerhead}> Explore </Typography>
          <Typography variant="caption" color="initial" className={styles.footerpara}>lorem ipsum</Typography>
          <Typography variant="caption" color="initial" className={styles.footerpara}>lorem ipsum</Typography>
          <Typography variant="caption" color="initial" className={styles.footerpara}>lorem ipsum</Typography>
          <Typography variant="caption" color="initial" className={styles.footerpara}>lorem ipsum</Typography>
          <Typography variant="caption" color="initial" className={styles.footerpara}>lorem ipsum</Typography>
        </Grid>
      </Grid>
    </Box>
    </Box>
  )
}

export default Footer